/*
 Copyright © 2018 Ribbon. All Rights Reserved.
 Ribbon CONFIDENTIAL. All information, copyrights, trade secrets
 and other intellectual property rights, contained herein are the property
 of Ribbon. This document is strictly confidential and must not be
 copied, accessed, disclosed or used in any manner, in whole or in part,
 without Ribbon's express written authorization.
 */

#import <UIKit/UIKit.h>

//! Project version number for CPAddressBookService.
FOUNDATION_EXPORT double CPAddressBookServiceVersionNumber;

//! Project version string for CPAddressBookService.
FOUNDATION_EXPORT const unsigned char CPAddressBookServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CPAddressBookService/PublicHeader.h>


