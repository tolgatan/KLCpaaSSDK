/*
 * Copyright © 2018 Ribbon. All Rights Reserved.
 *
 * Ribbon CONFIDENTIAL. All information, copyrights, trade secrets
 * and other intellectual property rights, contained herein are the property
 * of Ribbon. This document is strictly confidential and must not be
 * copied, accessed, disclosed or used in any manner, in whole or in part,
 * without Ribbon's express written authorization.
 *
 */

#import <UIKit/UIKit.h>

//! Project version number for PushManager.
FOUNDATION_EXPORT double PushManagerVersionNumber;

//! Project version string for AuthenticationService.
FOUNDATION_EXPORT const unsigned char PushManagerVersionString[];


